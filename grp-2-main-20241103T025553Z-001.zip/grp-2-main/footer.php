<!-- Footer -->
<footer class="footer">
 <div class="footer-content">
  <p>
   <i class="fas fa-copyright"></i> 2024 Group 2. All rights reserved.
  </p>
 </div>
</footer>

<!-- Scroll to Top Button -->
<button onclick="scrollToTop()" id="backToTop">↑</button>

<!-- JavaScript Files -->
<script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
<script src="grp2.js"></script>

</body>

</html>